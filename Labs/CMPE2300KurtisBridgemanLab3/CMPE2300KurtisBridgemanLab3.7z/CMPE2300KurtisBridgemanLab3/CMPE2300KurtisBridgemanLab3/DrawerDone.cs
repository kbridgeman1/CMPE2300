﻿//********************************************************************************
//Program:  DrawerDone.cs
//Author:   Kurtis Bridgeman
//Class:    CMPE2300
//********************************************************************************



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMPE2300KurtisBridgemanLab3
{
    public partial class DrawerDone : Form
    {
        public DrawerDone()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.OK;
        }
    }
}
